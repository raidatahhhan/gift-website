scrollme
========

A jQuery plugin for adding simple scrolling effects to web pages.

Demo and usage guide: http://scrollme.nckprsn.com.

Play with it on CodePen: http://codepen.io/nckprsn/pen/IGpmc
